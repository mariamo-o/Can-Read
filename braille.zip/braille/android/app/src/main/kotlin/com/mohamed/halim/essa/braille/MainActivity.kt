package com.mohamed.halim.essa.braille

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
